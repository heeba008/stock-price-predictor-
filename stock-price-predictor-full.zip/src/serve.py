from flask import Flask, jsonify, request
import joblib
from .data import download_price_data
from .features import make_features
from .config import MODELS_DIR, DEFAULT_TICKER

app = Flask(__name__)

@app.route("/predict", methods=["GET"])
def predict():
    ticker = request.args.get("ticker", DEFAULT_TICKER)
    model = joblib.load(MODELS_DIR / f"{ticker}_rf.joblib")
    feature_cols = joblib.load(MODELS_DIR / f"{ticker}_feature_cols.joblib")
    raw = download_price_data(ticker, start="2015-01-01")
    X, y, df = make_features(raw)
    X = X[feature_cols]
    latest_row = X.iloc[[-1]]
    pred = model.predict(latest_row)[0]
    return jsonify({"ticker": ticker, "predicted_next_close": float(pred)})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
