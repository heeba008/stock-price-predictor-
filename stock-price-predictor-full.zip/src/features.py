import numpy as np
import pandas as pd
from .utils import ensure_datetime_index, add_forward_target

def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = (delta.clip(lower=0)).ewm(alpha=1/period, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/period, adjust=False).mean()
    rs = gain / (loss + 1e-10)
    return 100 - (100 / (1 + rs))

def make_features(df: pd.DataFrame, target_col="Close", forecast_horizon=1):
    df = ensure_datetime_index(df.copy())
    df["ret_1d"] = df[target_col].pct_change()
    for w in [5, 10, 20]:
        df[f"sma_{w}"] = df[target_col].rolling(w).mean()
    df["rsi_14"] = rsi(df[target_col], 14)
    df = add_forward_target(df, col=target_col, steps=forecast_horizon, target_name="next_close")
    df = df.replace([np.inf, -np.inf], np.nan).dropna()
    feature_cols = [c for c in df.columns if c not in ["next_close"]]
    return df[feature_cols], df["next_close"], df
