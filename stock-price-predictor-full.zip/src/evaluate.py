from .train_sklearn import train_models
from .train_lstm import train_lstm

def compare_all():
    sk = train_models()
    lstm = train_lstm()
    print("Sklearn:", sk)
    print("LSTM:", lstm)

if __name__ == "__main__":
    compare_all()
