import numpy as np
import pandas as pd

def ensure_datetime_index(df: pd.DataFrame) -> pd.DataFrame:
    if not isinstance(df.index, pd.DatetimeIndex):
        if "Date" in df.columns:
            df["Date"] = pd.to_datetime(df["Date"])
            df = df.set_index("Date")
        else:
            raise ValueError("DataFrame must have a DatetimeIndex or a 'Date' column.")
    return df.sort_index()

def train_test_time_split(df, test_ratio=0.15):
    n = len(df)
    split = int(n * (1 - test_ratio))
    return df.iloc[:split], df.iloc[split:]

def add_forward_target(df, col="Close", steps=1, target_name="next_close"):
    df[target_name] = df[col].shift(-steps)
    return df

def safe_dropna(df):
    return df.replace([np.inf, -np.inf], np.nan).dropna()
