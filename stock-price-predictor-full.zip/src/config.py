from pathlib import Path

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
MODELS_DIR = Path(__file__).resolve().parents[1] / "models"

RAW_DIR.mkdir(parents=True, exist_ok=True)
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_TICKER = "AAPL"
START_DATE = "2010-01-01"
END_DATE = None
SEED = 42
TARGET = "next_close"
TEST_RATIO = 0.15
N_SPLITS = 5
WINDOW_LSTM = 60
