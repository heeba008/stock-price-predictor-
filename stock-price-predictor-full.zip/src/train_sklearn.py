import joblib
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import TimeSeriesSplit, GridSearchCV

from .config import MODELS_DIR, DEFAULT_TICKER, TEST_RATIO, N_SPLITS, SEED
from .data import download_price_data
from .features import make_features
from .metrics import summarize_regression
from .utils import train_test_time_split

def train_models(ticker=DEFAULT_TICKER):
    raw = download_price_data(ticker)
    X, y, _ = make_features(raw)
    df = X.copy()
    df["y"] = y
    train_df, test_df = train_test_time_split(df, test_ratio=TEST_RATIO)
    X_train, y_train = train_df.drop(columns=["y"]), train_df["y"]
    X_test, y_test = test_df.drop(columns=["y"]), test_df["y"]
    ridge_pipe = Pipeline([("scaler", StandardScaler()), ("model", Ridge(random_state=SEED))])
    rf = RandomForestRegressor(n_estimators=200, random_state=SEED)
    tscv = TimeSeriesSplit(n_splits=N_SPLITS)
    ridge_search = GridSearchCV(ridge_pipe, {"model__alpha": [0.1, 1.0]}, cv=tscv, scoring="neg_root_mean_squared_error")
    ridge_search.fit(X_train, y_train)
    rf.fit(X_train, y_train)
    ridge_pred = ridge_search.best_estimator_.predict(X_test)
    rf_pred = rf.predict(X_test)
    ridge_metrics = summarize_regression(y_test, ridge_pred)
    rf_metrics = summarize_regression(y_test, rf_pred)
    results = {"ridge": ridge_metrics, "rf": rf_metrics}
    joblib.dump(rf, MODELS_DIR / f"{ticker}_rf.joblib")
    joblib.dump(list(X_train.columns), MODELS_DIR / f"{ticker}_feature_cols.joblib")
    return results
if __name__ == "__main__":
    print(train_models())
