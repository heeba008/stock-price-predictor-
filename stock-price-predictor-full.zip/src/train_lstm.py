import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
import joblib
from sklearn.preprocessing import StandardScaler
from .data import download_price_data
from .features import make_features
from .config import MODELS_DIR, DEFAULT_TICKER, TEST_RATIO, WINDOW_LSTM
from .utils import train_test_time_split
from .metrics import summarize_regression

def make_sequences(X, y, window):
    X_arr, y_arr = X.values, y.values
    seq_X, seq_y = [], []
    for i in range(window, len(X_arr)):
        seq_X.append(X_arr[i-window:i])
        seq_y.append(y_arr[i])
    return np.array(seq_X), np.array(seq_y)

def train_lstm(ticker=DEFAULT_TICKER):
    raw = download_price_data(ticker)
    X, y, _ = make_features(raw)
    df = X.copy()
    df["y"] = y
    train_df, test_df = train_test_time_split(df, test_ratio=TEST_RATIO)
    X_train, y_train = train_df.drop(columns=["y"]), train_df["y"]
    X_test, y_test = test_df.drop(columns=["y"]), test_df["y"]
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    Xtr_seq, ytr_seq = make_sequences(pd.DataFrame(X_train_scaled, index=X_train.index), y_train, WINDOW_LSTM)
    Xte_seq, yte_seq = make_sequences(pd.DataFrame(X_test_scaled, index=X_test.index), y_test, WINDOW_LSTM)
    model = models.Sequential([layers.Input(shape=(Xtr_seq.shape[1], Xtr_seq.shape[2])), layers.LSTM(32), layers.Dense(1)])
    model.compile(optimizer="adam", loss="mse")
    model.fit(Xtr_seq, ytr_seq, epochs=5, batch_size=32, verbose=1)
    preds = model.predict(Xte_seq).reshape(-1)
    metrics = summarize_regression(yte_seq, preds)
    model.save(MODELS_DIR / f"{ticker}_lstm.keras")
    joblib.dump(scaler, MODELS_DIR / f"{ticker}_lstm_scaler.joblib")
    return metrics

if __name__ == "__main__":
    print(train_lstm())
