import yfinance as yf
import pandas as pd
from .utils import ensure_datetime_index
from .config import RAW_DIR, START_DATE, END_DATE

def download_price_data(ticker, start=START_DATE, end=END_DATE, interval="1d", auto_adjust=True, cache=True):
    path = RAW_DIR / f"{ticker}_{interval}.parquet"
    if cache and path.exists():
        return pd.read_parquet(path)

    df = yf.download(ticker, start=start, end=end, interval=interval, auto_adjust=auto_adjust, progress=False)
    df = df.reset_index().rename(columns=str.title)
    df = ensure_datetime_index(df)
    if cache:
        df.to_parquet(path)
    return df
