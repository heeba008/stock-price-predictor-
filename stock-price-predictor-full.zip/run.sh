#!/usr/bin/env bash
set -e
python -m src.evaluate
python -m src.serve
